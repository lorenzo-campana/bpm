#include <stdio.h>
#include <string.h>
#include <dbDefs.h>
#include <registryFunction.h>
#include <subRecord.h>
#include <aSubRecord.h>
#include <epicsExport.h>
#include <wiringPi.h>
void interrupt10hz ();
int mySubDebug;


static long mySubInit(subRecord *precord)
{}

static long mySubProcess(subRecord *precord)
{}



static long pin1Init(subRecord *precord)
{
    if (mySubDebug)
        printf("Record %s called pin1Init(%p)\n",
               precord->name, (void*) precord);
    if (wiringPiSetup () < 0) {
      printf ( "Unable to setup wiringPi: %s\n");
      return 1;
    }

    pinMode(3,OUTPUT);
    digitalWrite(3,0);
    return 0;
}

static long pin1Process(subRecord *precord)
{
    int channel;
    char channel_str[50];


    if (mySubDebug)
        printf("Record %s called pin1Process(%p)\n",
               precord->name, (void*) precord);

    channel=precord->val;

    sprintf(channel_str,"%d",channel);

    digitalWrite(3,1);
    delay(500);
    digitalWrite(3,0);
    precord->e=channel_str[1]-48;


    return 0;
}

static long tenhz_monitorInit(subRecord *precord)
{
    if (mySubDebug)
        printf("Record %s called 10hz_monitorInit(%p)\n",
               precord->name, (void*) precord);

    if (wiringPiSetup () < 0) {
      printf ("Unable to setup wiringPi: %s\n");
      return 1;
    }
    pinMode(4, INPUT);
    wiringPiISR(4, INT_EDGE_FALLING, &interrupt10hz);
    return 0;
}


void interrupt10hz() {
    pinMode(5,OUTPUT);
    digitalWrite(5,0);
    
}

static long tenhz_monitorProcess(subRecord *precord)
{
    if (mySubDebug)
        printf("Record %s called 10hz_monitorProcess(%p)\n",
               precord->name, (void*) precord);
    return 0;
}
 
static long myAsubInit(aSubRecord *precord)
{
    if (mySubDebug)
        printf("Record %s called myAsubInit(%p)\n",

               precord->name, (void*) precord);
    return 0;
}

static long myAsubProcess(aSubRecord *precord)
{
    if (mySubDebug)
        printf("Record %s called myAsubProcess(%p)\n",
               precord->name, (void*) precord);
    return 0;
}

/* Register these symbols for use by IOC code: */

epicsExportAddress(int, mySubDebug);
epicsRegisterFunction(pin1Init);
epicsRegisterFunction(pin1Process);
epicsRegisterFunction(tenhz_monitorInit);
epicsRegisterFunction(tenhz_monitorProcess);
epicsRegisterFunction(myAsubInit);
epicsRegisterFunction(myAsubProcess);
epicsRegisterFunction(mySubInit);
epicsRegisterFunction(mySubProcess);

