#include <stdio.h>
#include <string.h>
#include <dbDefs.h>
#include <registryFunction.h>
#include <subRecord.h>
#include <aSubRecord.h>
#include <epicsExport.h>
#include <wiringPi.h>
#include <math.h>


int mode=0;
int cycles = 10;
int dwell_time = 1;

void interrupt10hz ();
int mySubDebug;


static long mySubInit(subRecord *precord)
{}

static long mySubProcess(subRecord *precord)
{}




static long pin1Init(subRecord *precord){
  if (mySubDebug)
    printf("Record %s called pin1Init",
	   precord->name, (void*) precord);
  if (wiringPiSetup () < 0) {
    printf ( "Unable to setup wiringPi");
    return 1;
  }
  pinMode(0, OUTPUT);
  pinMode(1, OUTPUT);
  pinMode(2, OUTPUT);
  pinMode(3, OUTPUT);
  pinMode(4, OUTPUT);
  wiringPiISR(6, INT_EDGE_FALLING, &interrupt10hz);
  
  return 0;
}


static long pin1Process(subRecord *precord)
{
  union data {
    struct{
      unsigned int a:1;
      unsigned int b:1;
      unsigned int c:1;
      unsigned int d:1;
      unsigned int e:1;
    }outputs;
    unsigned char value;
  }converter;
  
  int channel;
  unsigned char bits;
  char c;

  
  if(precord->a){
    
    channel=pow(2,precord->b);
    for (bits=0; bits<16; bits++) {
      if (channel & 1) {precord->c=bits;c=bits;}
      channel>>=1;
    }
    
    converter.value=c+1;
    
    precord->f=converter.outputs.a;
    precord->g=converter.outputs.b;
    precord->h=converter.outputs.c;
    precord->i=converter.outputs.d;
    precord->j=converter.outputs.e;
    
    digitalWrite(0,precord->f);
    digitalWrite(1,precord->g);
    digitalWrite(2,precord->h);
    digitalWrite(3,precord->i);
    digitalWrite(4,precord->j);
    
  }


  if(precord->a==0 & mode==1){
    
    
    int mask=0b1;
    int channels[15]={0};
    int i;
    int j;
    int number;
    union data {
      struct{
	unsigned int a:1;
	unsigned int b:1;
	unsigned int c:1;
	unsigned int d:1;
	unsigned int e:1;
      }outputs;
      unsigned char value;
    }converter;
    for(j=0;j<cycles; j++){
      number=precord->k;    
      for(i=0;i<15;i++)
	{
	  if((number&(mask<<i))>0)
	    {
	      printf("%d\n",i);
	      converter.value=i+1;
	      precord->f=converter.outputs.a;
	      precord->g=converter.outputs.b;
	      precord->h=converter.outputs.c;
	      precord->i=converter.outputs.d;
	      precord->j=converter.outputs.e;
	      
	      digitalWrite(0,precord->f);
	      digitalWrite(1,precord->g);
	      digitalWrite(2,precord->h);
	      digitalWrite(3,precord->i);
	      digitalWrite(4,precord->j);
	      delay(dwell_time);
	      
	    }
	}
    }
    mode=0;
    printf("mode is: %d\n",mode);
      }
  
  return 0;
}

void interrupt10hz() {

  mode=1;
  
  /*  if(mode==0){
    
    
    int mask=0b1;
    int channels[15]={0};
    int i;
    union data {
      struct{
	unsigned int a:1;
	unsigned int b:1;
	unsigned int c:1;
	unsigned int d:1;
	unsigned int e:1;
      }outputs;
      unsigned char value;
    }converter;
    
    number=precord->m;    
    for(i=0;i<15;i++)
      {
	if((number&(mask<<i))>0)
	  {
	    converter.value=i+1;
	    precord->f=converter.outputs.a;
	    precord->g=converter.outputs.b;
	    precord->h=converter.outputs.c;
	    precord->i=converter.outputs.d;
	    precord->j=converter.outputs.e;
	    
	    digitalWrite(0,precord->f);
	    digitalWrite(1,precord->g);
	    digitalWrite(2,precord->h);
	    digitalWrite(3,precord->i);
	    digitalWrite(4,precord->j);
	    usleep(200);
	    
	  }
      }
      }*/
}

 
static long myAsubInit(aSubRecord *precord)
{
  if (mySubDebug)
    printf("Record %s called myAsubInit(%p)\n",
	   
               precord->name, (void*) precord);
  return 0;
}

static long myAsubProcess(aSubRecord *precord)
{
  if (mySubDebug)
    printf("Record %s called myAsubProcess(%p)\n",
	   precord->name, (void*) precord);
  return 0;
}

/* Register these symbols for use by IOC code: */

epicsExportAddress(int, mySubDebug);
epicsRegisterFunction(pin1Init);
epicsRegisterFunction(pin1Process);
epicsRegisterFunction(myAsubInit);
epicsRegisterFunction(myAsubProcess);
epicsRegisterFunction(mySubInit);
epicsRegisterFunction(mySubProcess);

