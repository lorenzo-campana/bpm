#include <stdio.h>
#include <string.h>
#include <dbDefs.h>
#include <registryFunction.h>
#include <subRecord.h>
#include <aSubRecord.h>
#include <epicsExport.h>
#include <wiringPi.h>
#include <math.h>
#include <time.h>
#include <sched.h>
#include <bcm2835.h>

#define DEF 0

#define PIN0 RPI_GPIO_P1_11
#define PIN1 RPI_GPIO_P1_12
#define PIN2 RPI_GPIO_P1_13
#define PIN3 RPI_GPIO_P1_15
#define PIN4 RPI_GPIO_P1_16


int number;
int mode=0;
int cycles;
int dwell_time;

int mySubDebug;


union data {
      struct{
	unsigned int a:1;
	unsigned int b:1;
	unsigned int c:1;
	unsigned int d:1;
	unsigned int e:1;
      }outputs;
      unsigned char value;
    };

void interrupt10hz() {
  if (mode==1) {
    
    //const struct sched_param priority = {1};
    //sched_setscheduler(0, SCHED_RR, &priority);
    piHiPri(99);
    piLock(0);
    int mask=0b1;
    int i;
    int j;
   
    
    union data converter2;
   
    for(j=0;j<cycles; j++){
      
      for(i=0;i<16;i++)
	{
	  if((number&(mask<<i))>0)
	    {
	     
	      converter2.value=i+1;
	      
	      //digitalWrite(0,converter2.outputs.a);
	      //digitalWrite(1,converter2.outputs.b);
	      //digitalWrite(2,converter2.outputs.c);
	      //digitalWrite(3,converter2.outputs.d);
	      //digitalWrite(4,converter2.outputs.e);
	      //usleep(dwell_time);

	      bcm2835_gpio_write(PIN0, converter2.outputs.a);
	      bcm2835_gpio_write(PIN1, converter2.outputs.b);
	      bcm2835_gpio_write(PIN2, converter2.outputs.c);
	      bcm2835_gpio_write(PIN3, converter2.outputs.d);
	      bcm2835_gpio_write(PIN4, converter2.outputs.e);
	      bcm2835_delayMicroseconds(dwell_time);
	      
	    }
	}
     
    }

    //digitalWrite(0,DEF);
    //digitalWrite(1,DEF);
    //digitalWrite(2,DEF);
    //digitalWrite(3,DEF);
    //digitalWrite(4,DEF);
    piUnlock(0);
    
  }//if close
 
  
}

static long mySubInit(subRecord *precord)
{}

static long mySubProcess(subRecord *precord)
{}




static long pin1Init(subRecord *precord){

  //const struct sched_param priority = {1};
  //sched_setscheduler(0, SCHED_RR, &priority);
  bcm2835_init();
  
  if (mySubDebug)
    printf("Record %s called pin1Init",
	   precord->name, (void*) precord);
  if (wiringPiSetup () < 0) {
    printf ( "Unable to setup wiringPi");
    return 1;
  }
  //pinMode(0, OUTPUT);
  //pinMode(1, OUTPUT);
  //pinMode(2, OUTPUT);
  //pinMode(3, OUTPUT);
  //pinMode(4, OUTPUT);
  wiringPiISR(6, INT_EDGE_FALLING, &interrupt10hz);
  bcm2835_gpio_fsel(PIN0, BCM2835_GPIO_FSEL_OUTP);
  bcm2835_gpio_fsel(PIN1, BCM2835_GPIO_FSEL_OUTP);
  bcm2835_gpio_fsel(PIN2, BCM2835_GPIO_FSEL_OUTP);
  bcm2835_gpio_fsel(PIN3, BCM2835_GPIO_FSEL_OUTP);
  bcm2835_gpio_fsel(PIN4, BCM2835_GPIO_FSEL_OUTP);



  return 0;
}


static long pin1Process(subRecord *precord)
{

  //const struct sched_param priority = {1};
  //sched_setscheduler(0, SCHED_RR, &priority);
  
  union data converter1;
  
  int channel;
  unsigned char bits;
  char c;
  dwell_time=precord->d;
  cycles=precord->e;
  
  if(precord->a){
    mode=0;
    channel=pow(2,precord->b);
    for (bits=0; bits<16; bits++) {
      if (channel & 1) {precord->c=bits;c=bits;}
      channel>>=1;
    }
    
    converter1.value=c+1;
    
    precord->f=converter1.outputs.a;
    precord->g=converter1.outputs.b;
    precord->h=converter1.outputs.c;
    precord->i=converter1.outputs.d;
    precord->j=converter1.outputs.e;
    
    digitalWrite(0,precord->f);
    digitalWrite(1,precord->g);
    digitalWrite(2,precord->h);
    digitalWrite(3,precord->i);
    digitalWrite(4,precord->j);
    
  }


  if(precord->a==0){
    
    number=precord->k;
    mode=1;
    
    
   
  }
  
  return 0;
}

 
static long myAsubInit(aSubRecord *precord)
{
  if (mySubDebug)
    printf("Record %s called myAsubInit(%p)\n",
	   
               precord->name, (void*) precord);
  return 0;
}

static long myAsubProcess(aSubRecord *precord)
{
  if (mySubDebug)
    printf("Record %s called myAsubProcess(%p)\n",
	   precord->name, (void*) precord);
  return 0;
}

/* Register these symbols for use by IOC code: */

epicsExportAddress(int, mySubDebug);
epicsRegisterFunction(pin1Init);
epicsRegisterFunction(pin1Process);
epicsRegisterFunction(myAsubInit);
epicsRegisterFunction(myAsubProcess);
epicsRegisterFunction(mySubInit);
epicsRegisterFunction(mySubProcess);

