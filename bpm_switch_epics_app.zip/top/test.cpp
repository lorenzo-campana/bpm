
#include<stdio.h>
#include <string.h>
#include <stdio.h>
/*void main() {
	union data {
		struct{
			unsigned int a:1;
			unsigned int b:1;
			unsigned int c:1;
			unsigned int d:1;
		}outputs;
		unsigned char c;
	}converter;

	converter.c=5;
	printf("a=%d\n",converter.outputs.a);
	printf("b=%d\n",converter.outputs.b);
	printf("c=%d\n",converter.outputs.c);
	printf("d=%d\n",converter.outputs.d);

	

	
	}*/
