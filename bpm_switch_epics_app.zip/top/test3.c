#include<stdio.h>
#include <string.h>

void main() {
  
  char bytes = 0xff;
  printf("%x",bytes);
  
  
  
  
}
