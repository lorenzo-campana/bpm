#include<stdio.h>
#include <string.h>
#include <sched.h>
#include <stdlib.h>

void main() {
	cpu_set_t bask;
	int output[8];
	int number=101;
	int mask=0b1;
	int channels[15]={0};
	char c=5;
	int i;
	int val;

	printf("%s\n",sched_getaffinity(0,sizeof(bask),&bask));     
  
	for(i=0;i<15;i++)
	{
	  if((number&(mask<<i))>0)
	  {
	    channels[i]=1;
	    printf("%d\n",channels[i]);
	  }
	  else
	  {
	    channels[i]=0;
	    printf("%d\n",channels[i]);
	  }
	}
	    
	
        
        
}
